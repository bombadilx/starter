export default [
  {
    title: 'Home',
    to: { name: 'root' },
    icon: { icon: 'bx-home-alt' },
  },
  {
    title: 'Posts',
    to: { name: 'posts' },
    icon: { icon: 'bx-file-blank' },
  },
]
