export default [
  {
    title: 'Home',
    to: { name: 'root' },
    icon: { icon: 'bx-home-alt' },
  },
  {
    title: 'Second page',
    to: { name: 'second-page' },
    icon: { icon: 'bx-file-blank' },
  },
]
