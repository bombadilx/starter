
<?php /**PATH C:\OSPanel6\home\starter-kit\resources\views\auth\login.blade.php ENDPATH**/ ?>