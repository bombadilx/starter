Attached you will find requested report.
<?php /**PATH C:\OSPanel6\home\starter-kit\vendor\yajra\laravel-datatables-export\src\resources\views\export-email.blade.php ENDPATH**/ ?>